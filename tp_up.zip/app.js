var bodyParser = require("body-parser");
var express = require ("express");
var methodOverride = require("express-method-override");
//var lpad = require("lpad");

//var horarios = require("./models/models").horarios;
//var usuarios = require("./models/models").usuarios;
//var campos = require("./models/models").campos;
//var lineas = require("./models/models").lineas;
//var torneos = require("./models/models").torneos;
var horarios = require("./models/bd").horarios;
var Usuario = require("./models/bd").Usuario;
var Campo = require("./models/bd").Campo;
var Linea = require("./models/bd").Linea;
var Torneo = require("./models/bd").Torneo;

var app = express();


app.use("/public",express.static("public"));
//app.use(express.static("public"));
//app.use(express.static("assets"));
app.use(bodyParser.json());//peticiones applicacion/json
app.use(bodyParser.urlencoded({extended: true}));//extended algorito decomo hacer parsing
//Para usar verbos Delete y Put
app.use(methodOverride('_method'));

app.set("view engine","jade");

//Metodo Verbos => GET / POST / PUT / PATCH / OPTION / HEADERS / DELETE
app.get("/",function(req, res){
    res.render("index");
});

app.get("/views/:link",function(req, res){
    //console.log(req.params.link);
    res.render(req.params.link);
});

//API USUARIOS
app.get("/api/usuarios/new",function(req, res){
    res.render("../views/alta_usuario");
});

app.get("/api/usuarios/:id/editar",function(req, res){
    //console.log("id: "+req.params.id);
    Usuario.findById(req.params.id,function(err,usuario){
        if(err) {
            //console.log("No encontre usuarios");
            res.send("No se encontro el usuario");
        }
        else{
         //paso el parametro imagenes devuelto por la funcion al parametro imagenes de la vista  
         //console.log("Edito usuarios: "+usuario);
         res.render("../views/editar_usuario",{usuario:usuario});
        }
    }); 
});

app.get("/api/usuarios/:id/eliminar",function(req, res){
    //console.log("id: "+req.params.id);
    Usuario.findById(req.params.id,function(err,usuario){
        if(err) {
            //console.log("No encontre usuarios");
            res.send("No se encontro el usuario");
        }
        else{
         //paso el parametro imagenes devuelto por la funcion al parametro imagenes de la vista  
         //console.log("Elimino usuario: "+usuario);
         res.render("../views/eliminar_usuario",{usuario:usuario});
        }
    }); 
});

app.route("/api/usuarios/")
.get(function(req, res){
    Usuario.find({},function(err,usuarios){
        if(err) {
            console.log("Error get usuario "+ err)
            res.redirect("/views/index");
        }
        else{
         //paso el parametro imagenes devuelto por la funcion al parametro imagenes de la vista  
         res.render("../views/mostrar_usuarios",{usuarios:usuarios});
        }
    }); 
})

.post(function(req, res){
    
    var usuario = new Usuario({nombre: req.body.nombre,
                                email: req.body.email.toLowerCase(), 
                                edad: req.body.edad
                                });
    usuario.save().then(function(us){
                        //Si todo sale bien
                        res.send("Dato guardado");
                        res.render("../views/mostrar_usuarios",{usuarios:usuarios});
                     }, function(err){
                           if(err){
                              //Si hubo errores
                              console.log(String(err));
                              res.send("No se pudo guardar "+ err);
                           }
                        }
                    );    
})
;

app.route("/api/usuarios/:id")
.get(function(req, res){
    Usuario.find({_id: req.params.id},function(err,usuarios){
        if(err) {
            res.send("No se encontro el usuario "+ err);
        }
        else{
         res.render("../views/mostrar_usuarios",{usuarios:usuarios});
        }
    }); 
})
.put(function(req, res){
    var consulta = {_id: req.params.id};
    var valores = { 
        $set: {
            nombre: req.body.nombre, 
            edad: req.body.edad,
            email: req.body.email
            } 
        };

    Usuario.updateOne(consulta, valores,function(err,usuarios){
        if(err) {
            res.send("No se encontro el usuario para editar " + err);
        }
        else{
         res.redirect("/api/usuarios");
        }
    });

                                
})
.delete(function(req, res){
    Usuario.deleteOne({_id: req.params.id},function(err,usuarios){
        if(err) {
            res.send("No se encontro el usuario para eliminar "+ err);
        }
        else{
         res.redirect("/api/usuarios");
        }
    });
})
;

//API CAMPOS
app.get("/api/campos/",function(req, res){

});

//API LINEAS
app.get("/api/lineas/",function(req, res){
    console.log("muestro lineas");
    /*User.find(function(err,doc){
        console.clear();
        console.log(doc);
    });
    

    res.end(JSON.stringify(lineas));
    //res.render("nuevo_usuario");
    */
});

//API TORNEOS
app.get("/api/torneos/",function(req, res){
    console.log("muestro torneos");
    /*
    User.find(function(err,doc){
        console.clear();
        console.log(doc);
    });
    

    res.end(JSON.stringify(torneos));
    res.render("nuevo_usuario");
    */
});



app.listen(8080);