var express = require("express");

var horarios = require("./models/bd").horarios;
var Usuario = require("./models/bd").Usuario;
var Campo = require("./models/bd").Campo;
var Linea = require("./models/bd").Linea;
var Torneo = require("./models/bd").Torneo;

var router = express.Router();

//API USUARIOS
//Redirige a la vista de alta
router.get("/usuarios/new",function(req, res){
    res.render("../views/alta_usuario");
});

//Muestra todos los usuarios
router.route("/usuarios/")
.get(function(req, res){
    Usuario.find({},function(err,usuarios){
        if(err) {
            //console.log("Error get usuario "+ err)
            res.send("No se encontro el usuario "+err);
        }
        else{
         //paso el parametro imagenes devuelto por la funcion al parametro imagenes de la vista  
         res.render("../views/mostrar_usuarios",{usuarios:usuarios});
        }
    }); 
})
//Crea nuevo usuario
.post(function(req, res){  
    var usuario = new Usuario({nombre: req.body.nombre,
                                email: req.body.email.toLowerCase(), 
                                edad: req.body.edad
                                });
    usuario.save().then(function(us){
                        //Si todo sale bien
                        res.send("Dato guardado");
                        res.render("../views/mostrar_usuarios",{usuarios:usuarios});
                     }, function(err){
                           if(err){
                              //Si hubo errores
                              console.log(String(err));
                              res.send("No se pudo guardar "+ err);
                           }
                        }
                    );    
})
;
//Muestra un usuario
router.route("/usuarios/:id")
.get(function(req, res){
    Usuario.find({_id: req.params.id},function(err,usuarios){
        if(err) {
            res.send("No se encontro el usuario "+ err);
        }
        else{
         res.render("../views/mostrar_usuarios",{usuarios:usuarios});
        }
    }); 
});
//Invoca a la vista de Editar para poder hacer PUT
router.get("/usuarios/:id/editar",function(req, res){
    //console.log("id: "+req.params.id);
    Usuario.findById(req.params.id,function(err,usuario){
        if(err) {
            //console.log("No encontre usuarios");
            res.send("No se encontro el usuario");
        }
        else{
         //paso el parametro imagenes devuelto por la funcion al parametro imagenes de la vista  
         res.render("../views/editar_usuario",{usuario:usuario});
        }
    }); 
});

//Invoca a la vista de Eliminar para poder hacer DELETE
router.get("/usuarios/:id/eliminar",function(req, res){
    //console.log("id: "+req.params.id);
    Usuario.findById(req.params.id,function(err,usuario){
        if(err) {
            //console.log("No encontre usuarios "+err);
            res.send("No se encontro el usuario a eliminar"+err);
        }
        else{
         //paso el parametro imagenes devuelto por la funcion al parametro imagenes de la vista  
         //console.log("Elimino usuario: "+usuario);
         res.render("../views/eliminar_usuario",{usuario:usuario});
        }
    }); 
});


//Edita usuario
router.route("/usuarios/:id")
.put(function(req, res){
    var consulta = {_id: req.params.id};
    var valores = { 
        $set: {
            nombre: req.body.nombre, 
            edad: req.body.edad,
            email: req.body.email
            } 
        };

    Usuario.updateOne(consulta, valores,function(err,usuarios){
        if(err) {
            res.send("No se encontro el usuario para editar " + err);
        }
        else{
         res.redirect("/api/usuarios");
        }
    });

                                
})
//Elimina usuario
.delete(function(req, res){
    Usuario.deleteOne({_id: req.params.id},function(err,usuarios){
        if(err) {
            res.send("No se encontro el usuario para eliminar "+ err);
        }
        else{
         res.redirect("/api/usuarios");
        }
    });
})
;

//API CAMPOS
router.get("/campos/",function(req, res){

});

//API LINEAS
router.get("/lineas/",function(req, res){
    console.log("muestro lineas");
    /*User.find(function(err,doc){
        console.clear();
        console.log(doc);
    });
    

    res.end(JSON.stringify(lineas));
    //res.render("nuevo_usuario");
    */
});

//API TORNEOS
router.get("/torneos/",function(req, res){
    console.log("muestro torneos");
    /*
    User.find(function(err,doc){
        console.clear();
        console.log(doc);
    });
    

    res.end(JSON.stringify(torneos));
    res.render("nuevo_usuario");
    */
});

module.exports = router;