var mongoose = require("mongoose");
mongoose.connect("mongodb://localhost/fotos", function(err, db) {
      if (err) throw err;
      console.log("BD Fotos creada!");
     // db.close();
});

var Schema = mongoose.Schema;

var posibles_valores = ["M","F"];

var email_match = [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,"El email es inválido"];

var password_validator = {validator: 
                            function(p){
                               return this.password_confirmation == p;
                            }, 
                            message: "Las contraseñas no son iguales"
};

//http://mongoosejs.com/docs/validation.html

var user_schema = new Schema({
    name:String,
    last_name:String,
    //username:{type: String, required:true},
    username: {type: String, 
               required: [true, "El username es obligatorio"], 
               maxlength:[50,"El usuario muy largo"]},
    //password:{type: String, required: true},
    password: {type: String, 
               required: "La contraseña es requerida", 
               minlength:[8, "La constraseña es muy corta"],
               validate: password_validator
    },
    age:{type: Number, 
         min: [5,"La edad no puede ser menos que 5"], 
         max: 105 },
    //email: {type: String, required: "El email es obligatorio"},//requerido
    //email: {type: String, required: [true, "El email es obligatorio"]},//requerido
    email:{type: String, 
           required: "El email es obligatorio", 
           match:email_match},//valida con expresion regular
    date_of_birth: Date,
    //sex: {type:String, enum:posibles_valores}//rango de valores definidos en un array
    sex:{type:String, 
         enum:{values: posibles_valores, message: "Opcion no válida"} }//Con mensaje de validacion
});

user_schema.virtual("password_confirmation").get(function(){
    return this.p_c;
}).set(function(password){
    this.p_c = password;
});

user_schema.virtual("full_name").get(function(){
    return this.name + " " + this.last_name;
}).set(function(full_name){
    var words = full_name.split(" ");
    this.name = words[0];
    this.last_name = words[1];
});

var User = mongoose.model("User",user_schema);

module.exports.User = User;

/*
String
Number
Date
Buffer
Boolean
Mixed
Objectid
Array
*/