var mongoose = require("../mongo").mongoose;

var Schema = mongoose.Schema;

//Validaciones especiales
var email_match = [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,"El email es inválido"];
//var posibles_valores_sexo = ["M","F"];

/*
String
Number
Date
Buffer
Boolean
Mixed
Objectid
Array
*/

//Esquemas

//Usuario
var usuario_schema = new Schema({
    nombre:{type: String,
            required: "El nombre de usuario es obligatorio"
        },
    apellido:{type: String,
            required: "El apellido de usuario es obligatorio"
        },
    email:{type: String, 
        required: "El email es obligatorio", 
        match:email_match},
    edad:{type: Number, 
                min: [6,"La edad no puede ser menor a 6"], 
                max: [100,"La edad no puede ser mayor a 100"] },
    hadicap:{type: Number, 
                    min: [0,"El handicap no puede ser menor a 0"], 
                    max: [100,  "El handicap no puede ser mayor a 100"]}
});
var Usuario = mongoose.model("Usuario",usuario_schema);
module.exports.Usuario = Usuario;

//Linea
var linea_schema = new Schema({
    lista:{type: Array,
            required: "La lista de personas es requerida"
        }
});
var Linea = mongoose.model("Linea",linea_schema);
module.exports.Linea = Linea;

//Campo
var campo_schema = new Schema({
    nombre:{type: String,
            required: "El nombre del campo es obligatorio"
        },
    ubicacion: String
});
var Campo = mongoose.model("Campo", campo_schema);
module.exports.Campo = Campo;

//Torneo
var torneo_schema = new Schema({
    fecha_torneo: Date,
    campo: {type: String,
        required: "El campo es obligatorio"
    },
    lista: {type: String,
        required: "La lista es obligatoria"
    }
});
var Torneo = mongoose.model("Torneo", torneo_schema);
module.exports.Torneo = Torneo;

//Listas estaticas
var horarios = [

    {id:  1, horario: '07:30hs - 08:30hs' },
    {id:  2, horario: '08:30hs - 09:30hs' },
    {id:  3, horario: '09:30hs - 10:30hs' },
    {id:  4, horario: '10:30hs - 11:30hs' },
    {id:  5, horario: '11:30hs - 12:30hs' },
    {id:  6, horario: '12:30hs - 13:30hs' },
    {id:  7, horario: '13:30hs - 14:30hs' },
    {id:  8, horario: '14:30hs - 15:30hs' },
    {id:  9, horario: '15:30hs - 16:30hs' },
    {id: 10, horario: '16:30hs - 17:30hs' },
    {id: 11, horario: '17:30hs - 18:30hs' },
    {id: 12, horario: '18:30hs - 19:30hs' }
];
module.exports.horarios = horarios;