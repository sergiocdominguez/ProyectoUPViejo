var mongoose = require("mongoose");
mongoose.connect("mongodb://localhost/tp", function(err, db) {
      if (err) throw err;
      console.log("BD creada!");
     // db.close();
});

module.exports.mongoose = mongoose;